/* ================================================================
   S. Vijaya Rajalakshmi — Portfolio JavaScript
   Author: S. Vijaya Rajalakshmi | Data Analyst & AI Enthusiast
================================================================ */

// ── Particles ──────────────────────────────────────────────────────────────
const canvas=document.getElementById('particles'),ctx=canvas.getContext('2d');
let W,H,pts=[];
function resize(){W=canvas.width=innerWidth;H=canvas.height=innerHeight;}
resize();addEventListener('resize',resize);
for(let i=0;i<70;i++)pts.push({x:Math.random()*innerWidth,y:Math.random()*innerHeight,r:Math.random()*1.4+0.4,dx:(Math.random()-.5)*.4,dy:(Math.random()-.5)*.4,op:Math.random()*.5+.1});
function drawPts(){
  ctx.clearRect(0,0,W,H);
  pts.forEach(p=>{
    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle='rgba(79,142,247,'+p.op+')';ctx.fill();
    p.x+=p.dx;p.y+=p.dy;
    if(p.x<0||p.x>W)p.dx*=-1;if(p.y<0||p.y>H)p.dy*=-1;
  });
  for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){
    const d=Math.hypot(pts[i].x-pts[j].x,pts[i].y-pts[j].y);
    if(d<110){ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y);ctx.strokeStyle='rgba(79,142,247,'+(0.1*(1-d/110))+')';ctx.lineWidth=.5;ctx.stroke();}
  }
  requestAnimationFrame(drawPts);
}
drawPts();

// ── Theme Toggle ──────────────────────────────────────────────────────────
const html=document.documentElement,ball=document.getElementById('themeBall');
document.getElementById('themeToggle').addEventListener('click',()=>{
  const dark=html.getAttribute('data-theme')==='dark';
  html.setAttribute('data-theme',dark?'light':'dark');
  ball.innerHTML=dark?'&#9728;':'&#127769;';
});

// ── Hamburger ──────────────────────────────────────────────────────────────
const ham=document.getElementById('hamburger'),mob=document.getElementById('mobileMenu');
ham.addEventListener('click',()=>{
  const open=mob.classList.toggle('open');
  const s=ham.querySelectorAll('span');
  s[0].style.transform=open?'rotate(45deg) translate(5px,5px)':'';
  s[1].style.opacity=open?'0':'1';
  s[2].style.transform=open?'rotate(-45deg) translate(5px,-5px)':'';
});
function closeMobile(){
  mob.classList.remove('open');
  const s=ham.querySelectorAll('span');
  s[0].style.transform='';s[1].style.opacity='1';s[2].style.transform='';
}

// ── Reveal on Scroll ──────────────────────────────────────────────────────
const revealEls=document.querySelectorAll('.reveal');
const revObs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(!e.isIntersecting)return;
    e.target.classList.add('visible');
    // Animate skill bars inside this element
    e.target.querySelectorAll('.bar-fill,.dbar-fill').forEach((b,i)=>{
      const w=b.getAttribute('data-w');
      if(w) setTimeout(()=>{b.style.width=w+'%';},100+i*80);
    });
    revObs.unobserve(e.target);
  });
},{threshold:0.1});
revealEls.forEach(el=>revObs.observe(el));

// ── Counter Animation ─────────────────────────────────────────────────────
function animCount(el,target,dec){
  let v=0;const inc=target/(2000/16);
  const t=setInterval(()=>{
    v=Math.min(v+inc,target);
    el.textContent=dec?v.toFixed(dec):Math.floor(v);
    if(v>=target){el.textContent=dec?target.toFixed(dec):target;clearInterval(t);}
  },16);
}
const cntObs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(!e.isIntersecting)return;
    e.target.querySelectorAll('[data-count]').forEach(el=>{
      const v=parseFloat(el.getAttribute('data-count'));
      const d=parseInt(el.getAttribute('data-dec')||0);
      animCount(el,v,d);
    });
    cntObs.unobserve(e.target);
  });
},{threshold:0.3});
document.querySelectorAll('.hero-stats,.kpi-grid').forEach(el=>cntObs.observe(el));

// ── Bar Chart Animation ───────────────────────────────────────────────────
const bcObs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(!e.isIntersecting)return;
    e.target.querySelectorAll('.bc-bar').forEach((b,i)=>{
      const h=b.getAttribute('data-h');
      setTimeout(()=>{b.style.height=h+'%';b.style.transition='height 0.8s ease';},i*70);
    });
    bcObs.unobserve(e.target);
  });
},{threshold:0.3});
const bc=document.getElementById('barChart');
if(bc)bcObs.observe(bc);

// ── Project Filter ────────────────────────────────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const f=btn.getAttribute('data-f');
    let n=0;
    document.querySelectorAll('.proj-card').forEach(card=>{
      const cats=(card.getAttribute('data-cat')||'').split(' ');
      const show=f==='all'||cats.includes(f);
      card.style.display=show?'flex':'none';
      if(show){card.style.opacity='0';card.style.transform='translateY(16px)';setTimeout(()=>{card.style.transition='opacity .4s,transform .4s';card.style.opacity='1';card.style.transform='translateY(0)';},n*55);n++;}
    });
  });
});

// ── Contact Form ──────────────────────────────────────────────────────────
function sendMsg(){
  const n=document.getElementById('cName').value.trim();
  const e=document.getElementById('cEmail').value.trim();
  const m=document.getElementById('cMessage').value.trim();
  if(!n||!e||!m){alert('Please fill in Name, Email, and Message.');return;}
  const s=document.getElementById('successMsg');
  s.style.display='block';
  document.getElementById('cName').value='';
  document.getElementById('cEmail').value='';
  document.getElementById('cSubject').value='';
  document.getElementById('cMessage').value='';
  setTimeout(()=>{s.style.display='none';},5000);
}

// ── Active Nav + Scroll Effects ───────────────────────────────────────────
const sections=document.querySelectorAll('section[id]');
const navLinks=document.querySelectorAll('.nav-links a');
const scrollBtn=document.getEleme